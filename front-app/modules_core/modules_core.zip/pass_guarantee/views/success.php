<div class="wrap">
    <style>
        .scroll-details{
            max-height: 450px;
            overflow-y: auto;
        }
    </style>
    <div class="allQusSec">
         <p> Your Payment Is Successfully Done.</p>
    </div>
</div>