<section>
  <div class="container">          
    <article>
	
	<div class="dil-box student-list">                
	  <article>
	    <h3 class="heading-txt">Video Tutorials</h3>
	    <div class="table-responsive">
	     <table>
	      <tr>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/l9adnkRJuuo" frameborder="0" allowfullscreen></iframe></td>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/XtjKeIE-JXM" frameborder="0" allowfullscreen></iframe></td>
	      </tr>
	      <tr>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/W19EeU_bQXM" frameborder="0" allowfullscreen></iframe></td>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/ip1JT89wdp0" frameborder="0" allowfullscreen></iframe></td>
	      </tr>
	      <tr>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/K6gYIJVPhYM" frameborder="0" allowfullscreen></iframe></td>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/3Q3xpouOQ_o" frameborder="0" allowfullscreen></iframe></td>
	      </tr>
	      <tr>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/rgUZyuzWMiY" frameborder="0" allowfullscreen></iframe></td>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/APByjOfk5u0" frameborder="0" allowfullscreen></iframe></td>
	      </tr>
	      <tr>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/XrdL8k48SJw" frameborder="0" allowfullscreen></iframe></td>
	       <td><iframe width="560" height="315" src="https://www.youtube.com/embed/5-3lXILEA9s" frameborder="0" allowfullscreen></iframe></td>
	      </tr>
	     </table>
	    </div>
	  </article>
	</div>
    </article>
  </div>        
</section>
